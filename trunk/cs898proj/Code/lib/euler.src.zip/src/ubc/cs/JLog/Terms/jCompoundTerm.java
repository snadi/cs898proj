/*
    This file is part of JLog.

    Created by Glendon Holst for Alan Mackworth and the 
    "Computational Intelligence: A Logical Approach" text.
    
    Copyright 1998, 2000, 2002, 2008 by University of British Columbia, 
    Alan Mackworth and Glendon Holst.
    
    This notice must remain in all files which belong to, or are derived 
    from JLog.
    
    Check <http://jlogic.sourceforge.net/> or 
    <http://sourceforge.net/projects/jlogic> for further information
    about JLog, or to contact the authors.

    JLog is free software, dual-licensed under both the GPL and MPL 
    as follows:

    You can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    Or, you can redistribute it and/or modify
    it under the terms of the Mozilla Public License as published by
    the Mozilla Foundation; version 1.1 of the License.

    JLog is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License, or the Mozilla Public License for 
    more details.

    You should have received a copy of the GNU General Public License
    along with JLog, in the file GPL.txt; if not, write to the 
    Free Software Foundation, Inc., 
    59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
    URLs: <http://www.fsf.org> or <http://www.gnu.org>

    You should have received a copy of the Mozilla Public License
    along with JLog, in the file MPL.txt; if not, contact:
    http://http://www.mozilla.org/MPL/MPL-1.1.html
    URLs: <http://www.mozilla.org/MPL/>
*/
//#########################################################################
//	CompoundTerm
//#########################################################################

package ubc.cs.JLog.Terms;

import java.lang.*;
import java.util.*;
import ubc.cs.JLog.Foundation.*;

/**
* This class represents a collection of terms.
* 
* @author       Glendon Holst
* @version      %I%, %G%
*/
public class jCompoundTerm extends jTerm implements iMakeUnmake
{
 protected ArrayList 	terms;

 public jCompoundTerm()
 {
  terms = new ArrayList();
  type = TYPE_COMPOUND;
 };

 public jCompoundTerm(int initialCapacity)
 {
  terms = new ArrayList(initialCapacity);
  type = TYPE_COMPOUND;
 };

 public jCompoundTerm(ArrayList t)
 {
  terms = t;
  type = TYPE_COMPOUND;
 };

 public int 		compare(jTerm term,boolean first_call,boolean var_equal)
 {jTerm 	t = term.getTerm();
   
  if (t instanceof jCompoundTerm)
  {ArrayList 		vt = ((jCompoundTerm) t).terms;
   int 			i,max = terms.size();
   int 			result;
    
   if (max < vt.size())
    return LESS_THAN;
   else if (max > vt.size())
    return GREATER_THAN;
    
   for (i = 0; i < max; i++)
   {
    result = ((jTerm) terms.get(i)).compare((jTerm) vt.get(i),true,var_equal);
    if (result != EQUAL)
     return result; 
   }
   return EQUAL;
  }
  
  return (first_call ? -t.compare(this,false,var_equal) : EQUAL);
 };

 public final boolean 		hasTerm(jTerm t)
 {
  return (terms.indexOf(t) >= 0); 
 };
 
 public void 			addTerm(jTerm t)
 {
  terms.add(t); 
 };
 
 public void 			removeTerm(jTerm t)
 {
  terms.remove(t);
 };
 
 public void 			removeAllTerms()
 {
  terms.clear();
 };
 
 public final Iterator 	enumTerms()
 {
  return terms.iterator();
 };
 
 public final int 			size()
 {
  return terms.size();
 };
 
 public final jTerm 		elementAt(int index)
 {
  return (jTerm) terms.get(index);
 };
 
 /**
  * Mutates a term element in the compount term.  
  * NOTE: Do not use this method, except in an exceptional circumstance, 
  * since it violates the logical consistency of standard Prolog.
  *
  * @param index	The zero-based index of the element to mutate.
  * @param term		The term to make the new element at index.
  *
  */
 public void			mutateElementAt(int index,jTerm term)
 {
  terms.set(index,term);
 };
 
 public final boolean 		isEmpty()
 {
  return terms.isEmpty();
 };
 
 public boolean 	requiresCompleteVariableState()
 {Iterator 	e;
 
  e = terms.iterator();
  
  while (e.hasNext())
   if (((jTerm) e.next()).requiresCompleteVariableState())
    return true;
  
  return false;
 };
 
 public void 		registerUnboundVariables(jUnifiedVector v)
 {int 		i,sz = terms.size();
 
  for (i = 0; i < sz; i++)
   ((jTerm) terms.get(i)).registerUnboundVariables(v);
 };

 public boolean 	equivalence(jTerm term,jEquivalenceMapping v)
 {jTerm t = term.getTerm();
 
  // only equiv with other compound terms of same type
  if (type != t.type)
   return false;
 
  // altough we cannot be certain that term is a jCompoundTerm, if it is not then type 
  // was wrong so this warrents a failing exception.
  {jCompoundTerm 	cterm;
   int 				sz;
   
   cterm = (jCompoundTerm) t;
   
   // only equivalence if terms have same size
   if ((sz = terms.size()) != cterm.terms.size())
    return false;

   {int 		i;
   
    // equiv each element of compound term, exit on first failure.
    for (i = 0; i < sz; i++)
     if (!((jTerm) terms.get(i)).equivalence((jTerm) cterm.terms.get(i),v))
      return false;
   }    
  }   
  return true;
 };

 public boolean 	unify(jTerm term,jUnifiedVector v)
 {
  // if term is variable we let it handle the unification
  if (term.type == TYPE_VARIABLE)
   return term.unify(this,v);

  // only unify with other compound terms of same type
  if (type != term.type)
   return false;
 
  // altough we cannot be certain that term is a jCompoundTerm, if it is not then type 
  // was wrong so this warrents a failing exception.
  {jCompoundTerm 	cterm;
   int 				sz;
   
   cterm = (jCompoundTerm) term;
   
   // only unify if terms have same size
   if ((sz = terms.size()) != cterm.terms.size())
    return false;

   {int 		i;
   
    // unify each element of compound term, exit on first unification failure.
    for (i = 0; i < sz; i++)
     if (!((jTerm) terms.get(i)).unify((jTerm) cterm.terms.get(i),v))
      return false;
   }    
  }   
  return true;
 };

 public void 		registerVariables(jVariableVector v)
 {Iterator 	e;
 
  e = terms.iterator();
  
  while (e.hasNext())
   ((jTerm) e.next()).registerVariables(v);
 };
 
 public void 		enumerateVariables(jVariableVector v,boolean all)
 {Iterator 	e;
 
  e = terms.iterator();
  
  while (e.hasNext())
   ((jTerm) e.next()).enumerateVariables(v,all);
 };

 public jTerm 		duplicate(jVariable[] vars)
 {  
  return new jCompoundTerm(internal_duplicate(vars));
 };
 
 protected ArrayList 	internal_duplicate(jVariable[] vars)
 {int 				i,sz = terms.size();
  ArrayList 			t = new ArrayList(sz);  

  for (i = 0;i < sz;i++)  
   t.add(((jTerm) terms.get(i)).duplicate(vars));
  
  return t;
 };
 
 public jTerm 		copy(jVariableRegistry vars)
 {
  return new jCompoundTerm(internal_copy(vars));
 };

 public ArrayList 		internal_copy(jVariableRegistry vars)
 {int 				i,sz = terms.size();
  ArrayList 			t = new ArrayList(sz);  

  for (i = 0;i < sz;i++)  
   t.add(((jTerm) terms.get(i)).copy(vars));
  
  return t;
 };
 
 /**
  * Makes this a copy of the provided <code>jCompoundTerm</code>.
  *
  * @param ct		<code>jCompoundTerm</code> to duplicate.
  */
 public void 		copyCompoundTerm(jCompoundTerm ct)
 {
  terms = (ArrayList) ct.terms.clone();  
 };
 
 /**
  * Removes all <code>jTerms</code> in given <code>jCompoundTerm</code>
  * from this.
  *
  * @param ct		<code>jCompoundTerm</code> with terms to remove.
  */
 public void 		subtractCompoundTerm(jCompoundTerm ct)
 {Iterator 	e = ct.terms.iterator();
   
  while (e.hasNext())
   removeTerm((jTerm) e.next());
 };
 
 /**
  * Removes all <code>jTerms</code> not in given <code>jCompoundTerm</code>
  * from this.
  *
  * @param ct		<code>jCompoundTerm</code> with terms to keep.
  */
 public void 		unionCompoundTerm(jCompoundTerm ct)
 {Iterator 	e = ct.terms.iterator();
   
  while (e.hasNext())
  {jTerm 	t = (jTerm) e.next();
  
   if (!hasTerm(t))
    addTerm(t);
  }
 };
 
 /**
  * Adds all <code>jTerms</code> in given <code>jCompoundTerm</code>
  * to this.
  *
  * @param ct		<code>jCompoundTerm</code> with terms to add.
  */
 public void 		intersectionCompoundTerm(jCompoundTerm ct)
 {Iterator 	e = terms.iterator();
  ArrayList 		vt = new ArrayList(Math.min(size(),ct.size()));
   
  while (e.hasNext())
  {jTerm	t = (jTerm) e.next();
   
   if (ct.hasTerm(t))
    vt.add(t);
  }
  
  terms = vt;
 };
 
 /**
  * Makes this a representation of the provided <code>jTerm</code>. Invokes
  * <code>makeCompoundTerm</code>.
  *
  * @param t		<code>jTerm</code> using <code>jCons</code> to separate 
  * 			terms.
  */
 public void 		make(jTerm t)
 {
  removeAllTerms();
  makeCompoundTerm(t);
 };
 
 /**
  * Add <code>jCons</code> separated <code>jTerm</code>s to this
  * <code>jCompoundTerm</code>.
  *
  * @param t		<code>jTerm</code> using <code>jCons</code> to separate 
  * 			terms.
  */
 public void 		makeCompoundTerm(jTerm t)
 {
  while (t instanceof jCons)
  {
   addTerm(((jCons) t).getLHS());
   t = ((jCons) t).getRHS().getTerm();
  }
  addTerm(t);
 };
 
 /**
  * Creates a <code>jCons</code> separated <code>jTerm</code>s to 
  * represent this <code>jCompoundTerm</code>. Invokes 
  * <code>unmakeCompoundTerm</code> to perform work.
  *
  * @return		<code>jTerm</code> using <code>jCons</code> to separate 
  * 			terms. Duplicates this <code>jCompoundTerm</code>
  */
 public jTerm 					unmake()
 {
  return unmakeCompoundTerm();
 };
 
 /**
  * Creates a <code>jCons</code> separated <code>jTerm</code>s to 
  * represent this <code>jCompoundTerm</code>.
  *
  * @return		<code>jTerm</code> using <code>jCons</code> to separate 
  * 			terms. Duplicates this <code>jCompoundTerm</code>
  */
 public synchronized jTerm 		unmakeCompoundTerm()
 {int 		i;
  jTerm 	prev = null;
 
  for (i = terms.size() - 1; i >= 0; i--)
  {
   if (prev == null)
    prev = (jTerm) terms.get(i);
   else
    prev = new jCons((jTerm) terms.get(i),prev);
  }
  return prev;
 };
 
 public void 		consult(jKnowledgeBase kb)
 {Iterator 	e;
 
  e = enumTerms();
  
  while (e.hasNext())
   ((iConsultable) e.next()).consult(kb);
 };
 
 public void 		consultReset()
 {Iterator 	e;
 
  e = enumTerms();
  
  while (e.hasNext())
   ((iConsultable) e.next()).consultReset();
 };
 
 public String 		toString(boolean usename)
 {StringBuffer 	sb = new StringBuffer();
  Iterator 	e;
  boolean 		first = true;
  
  e = terms.iterator();
  
  sb.append(getStartingSymbol());
  while (e.hasNext())
  {jTerm 		t;
   boolean 		higher_priority;
   
   if (!first)
    sb.append(",");
  
   t = (jTerm) e.next();
   higher_priority = isHigherPriorityOperator(t) && (terms.size() > 1);
   
   if (higher_priority)
    sb.append("(");
    
   sb.append(t.toString(usename));
   
   if (higher_priority)
    sb.append(")");
    
   first = false;
  }
  sb.append(getEndingSymbol());
  
  return sb.toString();
 };
 
 protected String 	getStartingSymbol()
 {
  return "(";
 }; 
 
 protected String 	getEndingSymbol()
 {
  return ")";
 }; 
 
 /**
  * Determines if provided <code>jTerm</code> is of higher priority than ','.
  *
  * @param t 		The <code>jTerm</code> to evaluate.
  *
  * @return		<code>true</code> if <code>jTerm</code> is  a builtin operator
  * 			with higher priority than the ',' operator, <code>false</code>
  * 			otherwise.
  */
 protected boolean 	isHigherPriorityOperator(jTerm t)
 {
  return (t instanceof jOr || t instanceof jOrPredicate || 
  			t instanceof jCommand || t instanceof jIf);
 };
};
