package euler;

import java.io.*;
import java.util.*;

/**
 * Euler yap engine for SWI-Prolog wrapper
 * 
 * @author Jos De Roo
 */

public class Eyes {

	public static void main(String[] args) {
		System.out.println(runEyes(args));
	}

	/**
	 * runEyes method
	 * 
	 * @param args
	 *                [--ttl <time to live in msec>] see --help
	 * 
	 * @return the proof
	 */
	public static String runEyes(String[] args) {
		long ttl = 1800000;
		ArrayList<File> fs = new ArrayList<File>();
		int j = 4;
		String[] cmd = new String[j + args.length - (args[0].equals("--ttl") ? 2 : 0)];
		cmd[0] = "plcon";
		cmd[1] = "-g";
		cmd[2] = "write('#'),consult(user),nl,main";
		cmd[3] = "--";
		for (int i = 0; i < args.length; i++) {
			if (args[i].equals("--ttl"))
				ttl = Long.parseLong(args[++i]);
			else if (args[i].startsWith("http://localhost/.context")) {
				try {
					File f = File.createTempFile("eyes_", ".n3");
					fs.add(f);
					FileOutputStream fos = new FileOutputStream(f);
					OutputStreamWriter osw = new OutputStreamWriter(fos, "UTF8");
					osw.write(Codd.urlDecode(args[i]).substring(26));
					osw.flush();
					osw.close();
					cmd[j++] = f.getAbsolutePath();
				} catch (Throwable t) {
					t.printStackTrace();
				}
			} else
				cmd[j++] = args[i];
		}
		String inp = getEyes();
		Process pr = new Process(cmd, inp);
		pr.execute(ttl);
		for (File f : fs)
			f.delete();
		return pr.getOutput();
	}

	static String getEyes() {
		StringBuffer sb = new StringBuffer();
		try {
			InputStream is = Eyes.class.getClassLoader().getResourceAsStream("eyes.pl");
			BufferedReader br = new BufferedReader(new InputStreamReader(is, "UTF8"));
			String rl = null;
			while ((rl = br.readLine()) != null)
				sb.append(rl).append('\n');
		} catch (Throwable t) {
			t.printStackTrace();
		}
		return sb.toString();
	}
}
