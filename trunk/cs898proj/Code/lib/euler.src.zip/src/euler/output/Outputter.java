// $Id: Outputter.java 1537 2007-09-20 21:42:34Z josd $

package euler.output;

import java.util.Vector;
import java.util.Enumeration;

/**
 * This class manages the output from the euler component.
 */

public class Outputter implements ILogger, IProof, IResult {

	private static final Object LOCK = new Object();

	private static Outputter instance = null;

	public static boolean log = false;

	private Vector _logListeners = null;

	private Vector _proofListeners = new Vector();

	private Vector _resultListeners = new Vector();

	/* ***************************************************************** */
	/* ** START : Constructor and Destructor */
	/* ***************************************************************** */

	/**
	 * This method constructs an instance of the outputter class. This
	 * constructor is private because this class is a singleton. The only
	 * instance of this class should be retrieved via the getInstance()
	 * method.
	 */
	private Outputter() {
	}

	/**
	 * This class acts as a singleton. getInstance() returns the only
	 * instance of this class.
	 * 
	 * @return the only instance of this class
	 */
	public static Outputter getInstance() {
		synchronized (LOCK) {
			if (instance == null) {
				instance = new Outputter();
			}
		}
		return instance;
	}

	/**
	 * This method releases the only instance of this class. All internal
	 * state will be cleared.
	 */
	public static void releaseInstance() {
		synchronized (LOCK) {
			if (instance != null) {
				// clear all internal state
				instance._logListeners = null;
				instance._proofListeners = null;
				instance._resultListeners = null;
				// clear instance
				instance = null;
			}
		}
	}

	/* ***************************************************************** */
	/* ** END : Constructor and Destructor */
	/* ***************************************************************** */

	/* ***************************************************************** */
	/* ** START : Public methods */
	/* ***************************************************************** */

	/**
	 * This method registers a log listener. From now on this log listener
	 * will also receive log messages from the euler component
	 * 
	 * @param logger
	 *                the logger to be registered.
	 */
	public synchronized void addLogger(ILogger logger) {
		if (_logListeners == null) {
			_logListeners = new Vector();
			log = true;
		}
		if (!_logListeners.contains(logger)) {
			_logListeners.add(logger);
		}
	}

	/**
	 * This method unregisters a log listener. From now on this log listener
	 * will receive no log messages anymore from the euler component.
	 * 
	 * @param logger
	 *                the logger to be removed as a listener.
	 */
	public synchronized void removeLogger(ILogger logger) {
		if (_logListeners.contains(logger)) {
			_logListeners.remove(logger);
		}
		if (_logListeners.size() == 0) {
			_logListeners = null;
			log = false;
		}
	}

	/**
	 * This method registers a result listener. From now on this result
	 * listener will also receive the results of the different test cases
	 * 
	 * @param result
	 *                the result listener to be registered.
	 */
	public synchronized void addResultListener(IResult result) {
		if (!_resultListeners.contains(result)) {
			_resultListeners.add(result);
		}
	}

	/**
	 * This method unregisters a result listener. From now on this result
	 * listener will receive no results anymore from the euler component.
	 * 
	 * @param result
	 *                the result listener to be removed.
	 */
	public synchronized void removeResultListener(IResult result) {
		if (_resultListeners.contains(result)) {
			_resultListeners.remove(result);
		}
	}

	/**
	 * This method registers a proof listener. From now on this proof
	 * listener will also receive the proofs of the different test cases
	 * 
	 * @param proof
	 *                the proof listener to be registered.
	 */
	public synchronized void addProofListener(IProof proof) {
		if (!_proofListeners.contains(proof)) {
			_proofListeners.add(proof);
		}
	}

	/**
	 * This method unregisters a proof listener. From now on this proof
	 * listener will receive no proofs anymore from the euler component.
	 * 
	 * @param proof
	 *                the proof listener to be removed.
	 */
	public synchronized void removeProofListener(IProof proof) {
		if (_proofListeners.contains(proof)) {
			_proofListeners.remove(proof);
		}
	}

	/* ***************************************************************** */
	/* ** END : Public methods */
	/* ***************************************************************** */

	/* ***************************************************************** */
	/* ** START : Implementation of interface ILogger */
	/* ***************************************************************** */

	/**
	 * This method distributes a log message to the different interested log
	 * listeners
	 * 
	 * @param className
	 *                the name of the class that initiated the message
	 * @param methodName
	 *                the method that initiated the log message
	 * @param message
	 *                the log message
	 * @param logLevel
	 *                the log level
	 */
	public synchronized void log(String className, String methodName, String message, int logLevel) {
		if (_logListeners != null) {
			for (Enumeration en = _logListeners.elements(); en.hasMoreElements();) {
				((ILogger) en.nextElement()).log(className, methodName, message, logLevel);
			}
		}
	}

	/* ***************************************************************** */
	/* ** END : Implementation of interface ILogger */
	/* ***************************************************************** */

	/* ***************************************************************** */
	/* ** START : Implementation of interface IResult */
	/* ***************************************************************** */

	/**
	 * This method distributes the result of a test case to the different
	 * interested listeners.
	 * 
	 * @param testCase
	 *                the name of the test case
	 * @param result
	 *                the result of the test case
	 */
	public synchronized void result(String testCase, String result) {
		for (Enumeration en = _resultListeners.elements(); en.hasMoreElements();) {
			((IResult) en.nextElement()).result(testCase, result);
		}
	}

	/* ***************************************************************** */
	/* ** END : Implementation of interface IResult */
	/* ***************************************************************** */

	/* ***************************************************************** */
	/* ** START : Implementation of interface IProof */
	/* ***************************************************************** */

	/**
	 * This method reports the proof for a specific test case
	 * 
	 * @param testCase
	 *                the name of the test case
	 * @param proof
	 *                the proof (if found)
	 */
	public synchronized void proof(String testCase, String proof) {
		for (Enumeration en = _proofListeners.elements(); en.hasMoreElements();) {
			((IProof) en.nextElement()).proof(testCase, proof);
		}
	}

	/* ***************************************************************** */
	/* ** END : Implementation of interface IProof */
	/* ***************************************************************** */
}
