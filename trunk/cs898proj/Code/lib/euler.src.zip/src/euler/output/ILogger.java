// $Id: ILogger.java 1537 2007-09-20 21:42:34Z josd $

package euler.output;

public interface ILogger {

	public static final int SEVERE = 0; // highest priority

	public static final int WARNING = 1;

	public static final int INFO = 2;

	public static final int CONFIG = 3;

	public static final int FINE = 4;

	public static final int FINER = 5;

	public static final int FINEST = 6; // lowest priority

	/**
	 * This method logs a certain message to a log system
	 * 
	 * @param className
	 *                the name of the class that initiated the message
	 * @param methodName
	 *                the method that initiated the log message
	 * @param message
	 *                the log message
	 * @param logLevel
	 *                the log level
	 */
	void log(String className, String methodName, String message, int logLevel);
}
