// $Id: IProof.java 1537 2007-09-20 21:42:34Z josd $

package euler.output;

public interface IProof {

	/**
	 * This method reports the proof for a specific test case
	 * 
	 * @param testCase
	 *                the name of the test case
	 * @param proof
	 *                the proof (if found)
	 */
	void proof(String testCase, String proof);
}
