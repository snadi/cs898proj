package euler;

import ubc.cs.JLog.Terms.*;
import ubc.cs.JLog.Foundation.*;
import ubc.cs.JLog.Builtins.*;
import ubc.cs.JLog.Terms.Goals.*;

public class jThrow extends jUnaryBuiltinPredicate {

	public jThrow(jTerm l) {
		super(l, TYPE_BUILTINPREDICATE);
	}

	public String getName() {
		return "throw";
	}

	public boolean prove(jUnaryBuiltinPredicateGoal bg) {
		jTerm l = bg.term1.getTerm();
		throw new RuntimeException(l.toString());
	}

	public jUnaryBuiltinPredicate duplicate(jTerm l) {
		return new jThrow(l);
	}
}
