package euler;

import java.io.*;
import java.net.*;
import com.hp.hpl.jena.mem.*;
import com.hp.hpl.jena.rdf.model.*;
import com.hp.hpl.jena.shared.*;

public class RdfXml {

	public static String getTriples(String in) {
		try {
			String b = in;
			Model mm = new ModelMem();
			RDFReader r = mm.getReader("RDF/XML");
			try {
				URL url = new URL(in);
				r.read(mm, in);
			} catch (Exception e) {
				File fi = new File(in);
				b = "file:///" + fi.getCanonicalPath().replace('\\', '/');
				r.read(mm, new FileInputStream(in), b);
			}
			RDFWriter w = mm.getWriter("N-TRIPLE");
			StringWriter sw = new StringWriter();
			w.write(mm, sw, b);
			return sw.toString();
		} catch (Exception exc) {
			throw new RuntimeException(in);
		}
	}

	public static String putTriples(String in) {
		try {
			Model mm = new ModelMem();
			RDFReader r = mm.getReader("N3");
			StringReader sr = new StringReader(in);
			r.read(mm, sr, "");
			RDFWriter w = mm.getWriter("RDF/XML");
			StringWriter sw = new StringWriter();
			w.write(mm, sw, "");
			return sw.toString();
		} catch (Exception exc) {
			throw new RuntimeException(exc);
		}
	}

	public static String rdfcopy(String args[]) {
		if (args.length < 1)
			throw new RuntimeException("missing arguments");
		String in = args[0];
		String inlang = "RDF/XML";
		int j;
		for (j = 1; j < args.length && args[j].indexOf("=") != -1; j++)
			;
		int lastInProp = j;
		if (j < args.length)
			inlang = args[j];
		j++;
		String outlang = "N-TRIPLE";
		for (; j < args.length && args[j].indexOf("=") != -1; j++)
			;
		int lastOutProp = j;
		if (j < args.length)
			outlang = args[j];
		if (j + 1 < args.length)
			throw new RuntimeException("missing arguments");
		try {
			Model m = ModelFactory.createDefaultModel();
			String base = in;
			RDFReader rdr = m.getReader(inlang);
			for (j = 1; j < lastInProp; j++) {
				int eq = args[j].indexOf("=");
				rdr.setProperty(args[j].substring(0, eq), args[j].substring(eq + 1));
			}
			try {
				rdr.read(m, in);
			} catch (JenaException ex) {
				if (!(ex.getCause() instanceof MalformedURLException))
					throw ex;
				File f = new File(in);
				base = "file:///" + f.getCanonicalPath().replace('\\', '/');
				rdr.read(m, new FileInputStream(in), base);
			}
			RDFWriter w = m.getWriter(outlang);
			j++;
			for (; j < lastOutProp; j++) {
				int eq = args[j].indexOf("=");
				w.setProperty(args[j].substring(0, eq), args[j].substring(eq + 1));
			}
			StringWriter sw = new StringWriter();
			w.write(m, sw, base);
			return sw.toString();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
}
