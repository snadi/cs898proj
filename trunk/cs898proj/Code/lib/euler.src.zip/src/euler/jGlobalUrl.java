package euler;

import java.net.*;
import ubc.cs.JLog.Terms.*;
import ubc.cs.JLog.Foundation.*;
import ubc.cs.JLog.Builtins.*;
import ubc.cs.JLog.Terms.Goals.*;

public class jGlobalUrl extends jTrinaryBuiltinPredicate {

	public jGlobalUrl(jTerm l, jTerm r, jTerm t) {
		super(l, r, t, TYPE_BUILTINPREDICATE);
	}

	public String getName() {
		return "global_url";
	}

	public boolean prove(jTrinaryBuiltinPredicateGoal bg) {
		jTerm l = bg.term1.getTerm();
		jTerm r = bg.term2.getTerm();
		jTerm u = bg.term3.getTerm();
		String m = l.toString();
		String n = r.toString();
		try {
			jTerm result = new jAtom(new URL(new URL(n), m).toString());
			return u.unify(result, bg.unified);
		} catch (Throwable t) {
			t.printStackTrace();
			return false;
		}
	}

	public jTrinaryBuiltinPredicate duplicate(jTerm l, jTerm r, jTerm u) {
		return new jGlobalUrl(l, r, u);
	}
}
