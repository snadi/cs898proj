package euler;

import ubc.cs.JLog.Terms.*;
import ubc.cs.JLog.Foundation.*;
import ubc.cs.JLog.Builtins.*;
import ubc.cs.JLog.Terms.Goals.*;

public class jCnt extends jUnaryBuiltinPredicate {

	public jCnt(jTerm l) {
		super(l, TYPE_BUILTINPREDICATE);
	}

	public String getName() {
		return "cnt";
	}

	public boolean prove(jUnaryBuiltinPredicateGoal bg) {
		jTerm l = bg.term1.getTerm();
		jPrologServiceThread pst = (jPrologServiceThread) Thread.currentThread();
		jPrologServices p = pst.getPrologServices();
		Object o = p.getMap().get(l.toString());
		if (o == null) {
			p.getMap().put(l.toString(), new jInteger(1));
			return true;
		} else {
			p.getMap().put(l.toString(), new jInteger(((jInteger) o).getIntegerValue() + 1));
			return true;
		}
	}

	public jUnaryBuiltinPredicate duplicate(jTerm l) {
		return new jCnt(l);
	}
}
