package euler;

import ubc.cs.JLog.Terms.*;
import ubc.cs.JLog.Foundation.*;
import ubc.cs.JLog.Builtins.*;
import ubc.cs.JLog.Terms.Goals.*;

public class jUpcaseAtom extends jBinaryBuiltinPredicate {

	public jUpcaseAtom(jTerm l, jTerm r) {
		super(l, r, TYPE_BUILTINPREDICATE);
	}

	public String getName() {
		return "upcase_atom";
	}

	public boolean prove(jBinaryBuiltinPredicateGoal bg) {
		jTerm l = bg.term1.getTerm();
		jTerm r = bg.term2.getTerm();
		jTerm result = new jAtom(l.toString().toUpperCase());
		return r.unify(result, bg.unified);
	}

	public jBinaryBuiltinPredicate duplicate(jTerm l, jTerm r) {
		return new jUpcaseAtom(l, r);
	}
}
