package euler;

import ubc.cs.JLog.Terms.*;
import ubc.cs.JLog.Foundation.*;
import ubc.cs.JLog.Builtins.*;
import ubc.cs.JLog.Terms.Goals.*;

public class jTab extends jUnaryBuiltinPredicate {

	public jTab(jTerm l) {
		super(l, TYPE_BUILTINPREDICATE);
	}

	public String getName() {
		return "tab";
	}

	public boolean prove(jUnaryBuiltinPredicateGoal bg) {
		int n = Integer.parseInt(bg.term1.getTerm().toString());
		jPrologServiceThread pst = (jPrologServiceThread) Thread.currentThread();
		jPrologServices p = pst.getPrologServices();
		while (n-- > 0)
			p.printOutput(" ");
		return true;
	}

	public jUnaryBuiltinPredicate duplicate(jTerm l) {
		return new jTab(l);
	}
}
