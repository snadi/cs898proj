// $Id: NegativeEntailmentTest_etc2.java 1537 2007-09-20 21:42:34Z josd $

package euler.test;

import java.io.File;

// imports from junit.jar
import junit.framework.TestCase;

public class NegativeEntailmentTest_etc2 extends TestCase {

	/* ***************************************************************** */
	/* ** START : Constructor */
	/* ***************************************************************** */

	public NegativeEntailmentTest_etc2(String s) {
		super(s);
	}

	/* ***************************************************************** */
	/* ** END : Constructor */
	/* ***************************************************************** */

	/* ***************************************************************** */
	/* ** START : protected methods */
	/* ***************************************************************** */

	protected void setUp() {
	}

	protected void tearDown() {
		File f = new File("test.n3");
		f.delete();
	}

	/* ***************************************************************** */
	/* ** END : protected methods */
	/* ***************************************************************** */

	/* ***************************************************************** */
	/* ** START : test cases */
	/* ***************************************************************** */

	public void test_NegativeEntailmentTest_etc2_AnnotationProperty_001() {
		Data.executeTest(Data.NegativeEntailmentTests_etc2[0], this, "etc2-results-java.n3");
	}

	public void test_NegativeEntailmentTest_etc2_Class_004() {
		Data.executeTest(Data.NegativeEntailmentTests_etc2[1], this, "etc2-results-java.n3");
	}

	public void test_NegativeEntailmentTest_etc2_Class_005() {
		Data.executeTest(Data.NegativeEntailmentTests_etc2[2], this, "etc2-results-java.n3");
	}

	public void test_NegativeEntailmentTest_etc2_I4_6_004() {
		Data.executeTest(Data.NegativeEntailmentTests_etc2[3], this, "etc2-results-java.n3");
	}

	public void test_NegativeEntailmentTest_etc2_I4_6_005() {
		Data.executeTest(Data.NegativeEntailmentTests_etc2[4], this, "etc2-results-java.n3");
	}

	public void test_NegativeEntailmentTest_etc2_I5_5_006() {
		Data.executeTest(Data.NegativeEntailmentTests_etc2[5], this, "etc2-results-java.n3");
	}

	public void test_NegativeEntailmentTest_etc2_I5_5_007() {
		Data.executeTest(Data.NegativeEntailmentTests_etc2[6], this, "etc2-results-java.n3");
	}

	public void test_NegativeEntailmentTest_etc2_I5_8_005() {
		Data.executeTest(Data.NegativeEntailmentTests_etc2[7], this, "etc2-results-java.n3");
	}

	public void test_NegativeEntailmentTest_etc2_I5_8_007() {
		Data.executeTest(Data.NegativeEntailmentTests_etc2[8], this, "etc2-results-java.n3");
	}

	public void test_NegativeEntailmentTest_etc2_Ontology_003() {
		Data.executeTest(Data.NegativeEntailmentTests_etc2[9], this, "etc2-results-java.n3");
	}

	public void test_NegativeEntailmentTest_etc2_Restriction_005() {
		Data.executeTest(Data.NegativeEntailmentTests_etc2[10], this, "etc2-results-java.n3");
	}

	public void test_NegativeEntailmentTest_etc2_allValuesFrom_002() {
		Data.executeTest(Data.NegativeEntailmentTests_etc2[11], this, "etc2-results-java.n3");
	}

	public void test_NegativeEntailmentTest_etc2_descriptionlogic_209() {
		Data.executeTest(Data.NegativeEntailmentTests_etc2[12], this, "etc2-results-java.n3");
	}

	public void test_NegativeEntailmentTest_etc2_descriptionlogic_902() {
		Data.executeTest(Data.NegativeEntailmentTests_etc2[13], this, "etc2-results-java.n3");
	}

	public void test_NegativeEntailmentTest_etc2_descriptionlogic_904() {
		Data.executeTest(Data.NegativeEntailmentTests_etc2[14], this, "etc2-results-java.n3");
	}

	public void test_NegativeEntailmentTest_etc2_equivalentClass_005() {
		Data.executeTest(Data.NegativeEntailmentTests_etc2[15], this, "etc2-results-java.n3");
	}

	public void test_NegativeEntailmentTest_etc2_equivalentClass_008() {
		Data.executeTest(Data.NegativeEntailmentTests_etc2[16], this, "etc2-results-java.n3");
	}

	public void test_NegativeEntailmentTest_etc2_imports_002() {
		Data.executeTest(Data.NegativeEntailmentTests_etc2[17], this, "etc2-results-java.n3");
	}

	public void test_NegativeEntailmentTest_etc2_miscellaneous_301() {
		Data.executeTest(Data.NegativeEntailmentTests_etc2[18], this, "etc2-results-java.n3");
	}

	public void test_NegativeEntailmentTest_etc2_miscellaneous_302() {
		Data.executeTest(Data.NegativeEntailmentTests_etc2[19], this, "etc2-results-java.n3");
	}

	public void test_NegativeEntailmentTest_etc2_someValuesFrom_002() {
		Data.executeTest(Data.NegativeEntailmentTests_etc2[20], this, "etc2-results-java.n3");
	}

	/* ***************************************************************** */
	/* ** END : test cases */
	/* ***************************************************************** */
}
