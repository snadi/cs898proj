// $Id: PositiveEntailmentTest_etc1.java 1537 2007-09-20 21:42:34Z josd $

package euler.test;

import java.io.File;

// imports from junit.jar
import junit.framework.TestCase;

public class PositiveEntailmentTest_etc1 extends TestCase {

	/* ***************************************************************** */
	/* ** START : Constructor */
	/* ***************************************************************** */

	public PositiveEntailmentTest_etc1(String s) {
		super(s);
	}

	/* ***************************************************************** */
	/* ** END : Constructor */
	/* ***************************************************************** */

	/* ***************************************************************** */
	/* ** START : protected methods */
	/* ***************************************************************** */

	protected void setUp() {
	}

	protected void tearDown() {
		File f = new File("test.n3");
		f.delete();
	}

	/* ***************************************************************** */
	/* ** END : protected methods */
	/* ***************************************************************** */

	/* ***************************************************************** */
	/* ** START : test cases */
	/* ***************************************************************** */

	public void test_PositiveEntailmentTest_etc1_rdftests_rdfcore_datatypesintensional_xsdintegerstringincompatible() {
		Data.executeTest(Data.PositiveEntailmentTests_etc1[0], this, "etc1-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc1_rdftests_rdfcore_datatypes_nonwellformedliteral1() {
		Data.executeTest(Data.PositiveEntailmentTests_etc1[1], this, "etc1-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc1_rdftests_rdfcore_datatypes_plainliteralandxsdstring() {
		Data.executeTest(Data.PositiveEntailmentTests_etc1[2], this, "etc1-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc1_rdftests_rdfcore_datatypes_rangeclash() {
		Data.executeTest(Data.PositiveEntailmentTests_etc1[3], this, "etc1-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc1_rdftests_rdfcore_datatypes_semanticequivalencebetweendatatypes() {
		Data.executeTest(Data.PositiveEntailmentTests_etc1[4], this, "etc1-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc1_rdftests_rdfcore_datatypes_semanticequivalencewithintype1() {
		Data.executeTest(Data.PositiveEntailmentTests_etc1[5], this, "etc1-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc1_rdftests_rdfcore_datatypes_semanticequivalencewithintype2() {
		Data.executeTest(Data.PositiveEntailmentTests_etc1[6], this, "etc1-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc1_rdftests_rdfcore_datatypes_test008() {
		Data.executeTest(Data.PositiveEntailmentTests_etc1[7], this, "etc1-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc1_rdftests_rdfcore_datatypes_test010() {
		Data.executeTest(Data.PositiveEntailmentTests_etc1[8], this, "etc1-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc1_rdftests_rdfcore_pfps10_nonwellformedliteral1() {
		Data.executeTest(Data.PositiveEntailmentTests_etc1[9], this, "etc1-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc1_rdftests_rdfcore_rdfmsseqrepresentation_test002() {
		Data.executeTest(Data.PositiveEntailmentTests_etc1[10], this, "etc1-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc1_rdftests_rdfcore_rdfmsseqrepresentation_test003() {
		Data.executeTest(Data.PositiveEntailmentTests_etc1[11], this, "etc1-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc1_rdftests_rdfcore_rdfmsseqrepresentation_test004() {
		Data.executeTest(Data.PositiveEntailmentTests_etc1[12], this, "etc1-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc1_rdftests_rdfcore_rdfsentailment_test001() {
		Data.executeTest(Data.PositiveEntailmentTests_etc1[13], this, "etc1-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc1_rdftests_rdfcore_rdfsentailment_test002() {
		Data.executeTest(Data.PositiveEntailmentTests_etc1[14], this, "etc1-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc1_rdftests_rdfcore_rdfsnocyclesinsubClassOf_test001() {
		Data.executeTest(Data.PositiveEntailmentTests_etc1[15], this, "etc1-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc1_rdftests_rdfcore_rdfsnocyclesinsubPropertyOf_test001() {
		Data.executeTest(Data.PositiveEntailmentTests_etc1[16], this, "etc1-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc1_rdftests_rdfcore_rdfssubPropertyOfsemantics_test001() {
		Data.executeTest(Data.PositiveEntailmentTests_etc1[17], this, "etc1-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc1_rdftests_rdfcore_tex01_languagetagcase1() {
		Data.executeTest(Data.PositiveEntailmentTests_etc1[18], this, "etc1-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc1_rdftests_rdfcore_tex01_languagetagcase2() {
		Data.executeTest(Data.PositiveEntailmentTests_etc1[19], this, "etc1-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc1_rdftests_rdfcore_xmlsch02_whitespacefacet3() {
		Data.executeTest(Data.PositiveEntailmentTests_etc1[20], this, "etc1-results-java.n3");
	}

	/* ***************************************************************** */
	/* ** END : test cases */
	/* ***************************************************************** */
}
