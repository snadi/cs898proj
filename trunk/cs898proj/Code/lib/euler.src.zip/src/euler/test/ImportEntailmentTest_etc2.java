// $Id: ImportEntailmentTest_etc2.java 1537 2007-09-20 21:42:34Z josd $

package euler.test;

import java.io.File;

// imports from junit.jar
import junit.framework.TestCase;

public class ImportEntailmentTest_etc2 extends TestCase {

	/* ***************************************************************** */
	/* ** START : Constructor */
	/* ***************************************************************** */

	public ImportEntailmentTest_etc2(String s) {
		super(s);
	}

	/* ***************************************************************** */
	/* ** END : Constructor */
	/* ***************************************************************** */

	/* ***************************************************************** */
	/* ** START : protected methods */
	/* ***************************************************************** */

	protected void setUp() {
	}

	protected void tearDown() {
		File f = new File("test.n3");
		f.delete();
	}

	/* ***************************************************************** */
	/* ** END : protected methods */
	/* ***************************************************************** */

	/* ***************************************************************** */
	/* ** START : test cases */
	/* ***************************************************************** */

	public void test_ImportEntailmentTest_etc2_test001() {
		Data.executeTest(Data.ImportEntailmentTest_etc2[0], this, "etc2-results-java.n3");
	}

	public void test_ImportEntailmentTest_etc2_test003() {
		Data.executeTest(Data.ImportEntailmentTest_etc2[1], this, "etc2-results-java.n3");
	}

	public void test_ImportEntailmentTest_etc2_test011() {
		Data.executeTest(Data.ImportEntailmentTest_etc2[2], this, "etc2-results-java.n3");
	}

	/* ***************************************************************** */
	/* ** END : test cases */
	/* ***************************************************************** */
}
