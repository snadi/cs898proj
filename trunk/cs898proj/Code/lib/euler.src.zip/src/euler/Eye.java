package euler;

import java.io.*;
import java.util.*;

/**
 * Euler Yap Engine wrapper
 * 
 * @author Jos De Roo
 */

public class Eye {

	public static void main(String[] args) {
		System.out.println(runEye(args));
	}

	/**
	 * runEye method
	 * 
	 * @param args
	 *                [--ttl <time to live in msec>] [--path <yap path>] see --help
	 * 
	 * @return the proof
	 */
	public static String runEye(String[] args) {
		long ttl = 1800000;
		String path = "";
		int a = 0;
		for (int i = 0; i < args.length; i++) {
			if (args[i].equals("--ttl")) {
				ttl = Long.parseLong(args[++i]);
				a += 2;
			}
			else if (args[i].equals("--path")) {
				path = args[++i] + "/";
				a += 2;
			}
		}
		int j = 5;
		String[] cmd = new String[j + args.length - a];
		cmd[0] = path + "yap";
		cmd[1] = "-q";
		cmd[2] = "-g";
		cmd[3] = "consult(user),main";
		cmd[4] = "--";
		ArrayList<File> fs = new ArrayList<File>();
		for (int i = a; i < args.length; i++) {
			if (args[i].startsWith("http://localhost/.context")) {
				try {
					File f = File.createTempFile("eye_", ".n3");
					fs.add(f);
					FileOutputStream fos = new FileOutputStream(f);
					OutputStreamWriter osw = new OutputStreamWriter(fos, "UTF8");
					osw.write(Codd.urlDecode(args[i]).substring(26));
					osw.flush();
					osw.close();
					cmd[j++] = f.getAbsolutePath();
				} catch (Throwable t) {
					t.printStackTrace();
				}
			} else
				cmd[j++] = args[i];
		}
		String inp = getEye();
		Process pr = new Process(cmd, inp);
		pr.execute(ttl);
		for (File f : fs)
			f.delete();
		return pr.getOutput();
	}

	static String getEye() {
		StringBuilder sb = new StringBuilder();
		try {
			InputStream is = Eye.class.getClassLoader().getResourceAsStream("euler.yap");
			BufferedReader br = new BufferedReader(new InputStreamReader(is, "UTF8"));
			String rl = null;
			while ((rl = br.readLine()) != null)
				sb.append(rl).append('\n');
		} catch (Throwable t) {
			t.printStackTrace();
		}
		return sb.toString();
	}
}
