package euler;

public class Version {

  /** major verion number of this component */
  public static final int    MAJOR     = 1;
  /** minor version number of this component */
  public static final int    MINOR     = 5;
  /** build number of this component */
  public static final int    BUILD     = 94;
}
