package euler;

public class Configuration {

	private boolean _proofExplanation = true;
	private boolean _think = false;
	private boolean _runLocal = false;
	private long _steps = -1;

	private static final Object LOCK = new Object();
	private static Configuration instance = null;

	private Configuration() {
	}

	public static Configuration getInstance() {
		synchronized (LOCK) {
			if (instance == null) {
				instance = new Configuration();
			}
		}
		return instance;
	}

	public String getVersion() {
		return "" + Version.MAJOR + "." + Version.MINOR + "." + Version.BUILD;
	}

	public void setProofExplanation(boolean flag) {
		_proofExplanation = flag;
	}

	public boolean getProofExplanation() {
		return _proofExplanation;
	}

	public void setThink(boolean flag) {
		_think = flag;
	}

	public boolean getThink() {
		return _think;
	}

	public void setSteps(long steps) {
		_steps = steps;
	}

	public long getSteps() {
		return _steps;
	}

	public void setRunLocal(boolean flag) {
		_runLocal = flag;
	}

	public boolean getRunLocal() {
		return _runLocal;
	}
}
