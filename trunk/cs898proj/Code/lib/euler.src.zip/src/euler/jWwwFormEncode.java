package euler;

import java.net.*;
import ubc.cs.JLog.Terms.*;
import ubc.cs.JLog.Foundation.*;
import ubc.cs.JLog.Builtins.*;
import ubc.cs.JLog.Terms.Goals.*;

public class jWwwFormEncode extends jBinaryBuiltinPredicate {

	public jWwwFormEncode(jTerm l, jTerm r) {
		super(l, r, TYPE_BUILTINPREDICATE);
	}

	public String getName() {
		return "www_form_encode";
	}

	public boolean prove(jBinaryBuiltinPredicateGoal bg) {
		jTerm l = bg.term1.getTerm();
		jTerm r = bg.term2.getTerm();
		try {
			if (l instanceof jVariable) {
				if (((jVariable) l).isBound()) {
					jTerm result = new jAtom(URLEncoder.encode(l.toString(), "UTF-8"));
					return r.unify(result, bg.unified);
				} else {
					jTerm result = new jAtom(URLDecoder.decode(r.toString(), "UTF-8"));
					return l.unify(result, bg.unified);
				}
			} else {
				jTerm result = new jAtom(URLEncoder.encode(l.toString(), "UTF-8"));
				return r.unify(result, bg.unified);
			}
		} catch (Throwable t) {
			t.printStackTrace();
			return false;
		}
	}

	public jBinaryBuiltinPredicate duplicate(jTerm l, jTerm r) {
		return new jWwwFormEncode(l, r);
	}
}
