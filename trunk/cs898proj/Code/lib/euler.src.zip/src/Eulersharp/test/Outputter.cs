// $Id: Outputter.cs 1295 2007-05-11 16:52:51Z josd $

namespace Eulersharp.test 
{

  using System;
  using System.IO;
  using System.Collections;

  /// <summary>
  /// This class outputs the results and the proofs of the different tests
  /// </summary>
  public class Outputter 
  {

    private static readonly object    LOCK     = new object();
    private static          Outputter instance = null;

    private Hashtable _files = new Hashtable();

    /// <summary>
    /// This method constructs an outputter object. This constructor is
    /// private because this class acts as a singleton. The only instance of this
    /// class should be retrieved via the getInstance() method  
    /// </summary>
    private Outputter() 
    {
    }

    /// <summary>
    /// This method returns the only instance of this class
    /// </summary>
    /// <returns>the only instance of this class</returns>
    public static Outputter getInstance() 
    {
      lock (LOCK) 
      {
        if (instance == null) 
        {
          instance = new Outputter();
        }
      }
      return instance;
    }

    /// <summary>
    /// This method initializes the given file by writing a header to the file
    /// </summary>
    /// <param name="file">the file to be initialized.</param>
    public void initialize(String file) 
    {
      if (_files[file] == null) 
      {
        using (StreamWriter sw = new StreamWriter(file))
        {
          sw.WriteLine("@prefix r: <http://www.w3.org/2002/03owlt/resultsOntology#>.");
          sw.WriteLine("@prefix xsd: <http://www.w3.org/2001/XMLSchema#>.");
          sw.WriteLine("@prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#>.");
          sw.WriteLine("@prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>.");
          sw.WriteLine("@prefix : <#>.");
          sw.WriteLine();    
          sw.WriteLine(":eulersharp rdfs:comment \"\"\"<a xmlns=\"http://www.w3.org/1999/xhtml\" href=\"http://eulersharp.sourceforge.net/2003/03swap/\">EulerSharp</a>");
          sw.WriteLine("is an inference engine supporting logic based proofs.");
          sw.WriteLine("It is a backward-chaining reasoner enhanced with Euler path detection and will tell");
          sw.WriteLine("you whether a given set of facts and rules supports a given conclusion.");
          sw.WriteLine("To parse the manifests and the test documents Jena 2 is used.\"\"\"^^rdf:XMLLiteral;");
          sw.WriteLine("rdfs:label \"EulerSharp\";");
          sw.WriteLine("rdfs:seeAlso <http://eulersharp.sourceforge.net/2003/03swap/>.");
          sw.WriteLine();
          _files.Add(file, file);
        }
      }
    }

    /// <summary>
    /// This method adds the given result to the correct result file
    /// </summary>
    /// <param name="file">the file to be extended.</param>
    /// <param name="result">The result to be appended to the given result file</param>
    public void addToResult(String file, String result) 
    {
      using (StreamWriter sw = new StreamWriter(file, true))
      {
        sw.WriteLine(result);
      }
    }

    /// <summary>
    /// This method writes a proof into a given file
    /// </summary>
    /// <param name="file">the file to be extended.</param>
    /// <param name="proof">The proof to be saved in the given file</param>
    public void writeProof(String file, String proof) 
    {
      using (StreamWriter sw = new StreamWriter(file))
      {
        sw.WriteLine(proof);
      }
    }
  }
}
