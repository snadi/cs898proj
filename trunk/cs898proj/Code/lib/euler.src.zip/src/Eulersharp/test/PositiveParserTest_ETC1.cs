// $Id: PositiveParserTest_ETC1.cs 1295 2007-05-11 16:52:51Z josd $

namespace Eulersharp.test {

using System;
using System.IO;
using System.Reflection;

/// <summary>
/// Class to test the euler engine
/// </summary>
[NUnit.Framework.TestFixture]
public class PositiveParserTest_ETC1
{

  /// <summary>
  /// Code to set up the test
  /// </summary>
  [NUnit.Framework.SetUp]
  public void Init() 
  {
    Outputter.getInstance().initialize("etc1-results-net.n3");
  }

  /// <summary>
  /// Code to shut down the test
  /// </summary>
  [NUnit.Framework.TearDown]
  public void TearDown()
  {
    File.Delete("test.n3");
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_ampinurl_test001() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[0], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_datatypes_test001() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[1], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_datatypes_test002() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[2], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_rdfcharmodliterals_test001() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[3], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_rdfcharmoduris_test001() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[4], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_rdfcharmoduris_test002() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[5], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_rdfcontainerssyntaxvsschema_test001() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[6], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_rdfcontainerssyntaxvsschema_test002() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[7], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void  rdftests_rdfcore_rdfcontainerssyntaxvsschema_test003() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[8], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_rdfcontainerssyntaxvsschema_test004() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[9], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_rdfcontainerssyntaxvsschema_test006() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[10], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_rdfcontainerssyntaxvsschema_test007() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[11], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void
    rdftests_rdfcore_rdfcontainerssyntaxvsschema_test008() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[12], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void
    rdftests_rdfcore_rdfelementnotmandatory_test001() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[13], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void
    rdftests_rdfcore_rdfnsprefixconfusion_test0001() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[14], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void
    rdftests_rdfcore_rdfnsprefixconfusion_test0003() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[15], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void
    rdftests_rdfcore_rdfnsprefixconfusion_test0004() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[16], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void
    rdftests_rdfcore_rdfnsprefixconfusion_test0005() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[17], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void
    rdftests_rdfcore_rdfnsprefixconfusion_test0006() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[18], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void
    rdftests_rdfcore_rdfnsprefixconfusion_test0009() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[19], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void
    rdftests_rdfcore_rdfnsprefixconfusion_test0010() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[20], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void
    rdftests_rdfcore_rdfnsprefixconfusion_test0011() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[21], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void
    rdftests_rdfcore_rdfnsprefixconfusion_test0012() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[22], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void
    rdftests_rdfcore_rdfnsprefixconfusion_test0013() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[23], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void
    rdftests_rdfcore_rdfnsprefixconfusion_test0014() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[24], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void
    rdftests_rdfcore_rdfmsdifferencebetweenIDandabout_test1() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[25], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void
    rdftests_rdfcore_rdfmsdifferencebetweenIDandabout_test2() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[26], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void
    rdftests_rdfcore_rdfmsdifferencebetweenIDandabout_test3() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[27], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void
    rdftests_rdfcore_rdfmsduplicatememberprops_test001() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[28], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void
    rdftests_rdfcore_rdfmsemptypropertyelements_test001() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[29], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void
    rdftests_rdfcore_rdfmsemptypropertyelements_test002() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[30], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void
    rdftests_rdfcore_rdfmsemptypropertyelements_test003() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[31], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void
    rdftests_rdfcore_rdfmsemptypropertyelements_test004() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[32], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void
    rdftests_rdfcore_rdfmsemptypropertyelements_test005() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[33], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void
    rdftests_rdfcore_rdfmsemptypropertyelements_test006() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[34], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void
    rdftests_rdfcore_rdfmsemptypropertyelements_test007() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[35], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void
    rdftests_rdfcore_rdfmsemptypropertyelements_test009() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[36], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void
    rdftests_rdfcore_rdfmsemptypropertyelements_test010() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[37], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void
    rdftests_rdfcore_rdfmsemptypropertyelements_test011() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[38], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void
    rdftests_rdfcore_rdfmsemptypropertyelements_test012() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[39], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void
    rdftests_rdfcore_rdfmsemptypropertyelements_test013() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[40], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void
    rdftests_rdfcore_rdfmsemptypropertyelements_test014() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[41], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void
    rdftests_rdfcore_rdfmsemptypropertyelements_test015() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[42], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void
    rdftests_rdfcore_rdfmsemptypropertyelements_test016() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[43], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void
    rdftests_rdfcore_rdfmsemptypropertyelements_test017() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[44], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void
    rdftests_rdfcore_rdfmsidentityanonresources_test001() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[45], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void
    rdftests_rdfcore_rdfmsidentityanonresources_test002() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[46], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void
    rdftests_rdfcore_rdfmsidentityanonresources_test003() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[47], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void
    rdftests_rdfcore_rdfmsidentityanonresources_test004() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[48], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void
    rdftests_rdfcore_rdfmsidentityanonresources_test005() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[49], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void
    rdftests_rdfcore_rdfmsnotidandresourceattr_test001() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[50], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void
    rdftests_rdfcore_rdfmsnotidandresourceattr_test002() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[51], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void
    rdftests_rdfcore_rdfmsnotidandresourceattr_test004() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[52], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void
    rdftests_rdfcore_rdfmsnotidandresourceattr_test005() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[53], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_rdfmspara196_test001() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[54], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_rdfmsrdfnamesuse_test001() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[55], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_rdfmsrdfnamesuse_test002() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[56], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_rdfmsrdfnamesuse_test003() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[57], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_rdfmsrdfnamesuse_test004() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[58], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_rdfmsrdfnamesuse_test005() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[59], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_rdfmsrdfnamesuse_test006() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[60], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_rdfmsrdfnamesuse_test007() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[61], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_rdfmsrdfnamesuse_test008() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[62], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_rdfmsrdfnamesuse_test009() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[63], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_rdfmsrdfnamesuse_test010() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[64], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_rdfmsrdfnamesuse_test011() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[65], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_rdfmsrdfnamesuse_test012() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[66], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_rdfmsrdfnamesuse_test013() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[67], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_rdfmsrdfnamesuse_test014() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[68], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_rdfmsrdfnamesuse_test015() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[69], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_rdfmsrdfnamesuse_test016() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[70], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_rdfmsrdfnamesuse_test017() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[71], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_rdfmsrdfnamesuse_test018() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[72], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_rdfmsrdfnamesuse_test019() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[73], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_rdfmsrdfnamesuse_test020() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[74], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_rdfmsrdfnamesuse_test021() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[75], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_rdfmsrdfnamesuse_test023() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[76], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_rdfmsrdfnamesuse_test024() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[77], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_rdfmsrdfnamesuse_test025() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[78], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_rdfmsrdfnamesuse_test026() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[79], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_rdfmsrdfnamesuse_test027() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[80], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_rdfmsrdfnamesuse_test028() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[81], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_rdfmsrdfnamesuse_test029() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[82], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_rdfmsrdfnamesuse_test030() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[83], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_rdfmsrdfnamesuse_test031() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[84], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_rdfmsrdfnamesuse_test032() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[85], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_rdfmsrdfnamesuse_test033() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[86], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_rdfmsrdfnamesuse_test034() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[87], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_rdfmsrdfnamesuse_test035() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[88], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_rdfmsrdfnamesuse_test036() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[89], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_rdfmsrdfnamesuse_test037() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[90], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_rdfmsrdfnamesuse_warn001() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[91], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_rdfmsrdfnamesuse_warn002() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[92], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_rdfmsrdfnamesuse_warn003() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[93], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void
    rdftests_rdfcore_rdfmsreificationrequired_test001() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[94], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void
    rdftests_rdfcore_rdfmsseqrepresentation_test001() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[95], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void
    rdftests_rdfcore_rdfmssyntaxincomplete_test001() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[96], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void
    rdftests_rdfcore_rdfmssyntaxincomplete_test002() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[97], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void
    rdftests_rdfcore_rdfmssyntaxincomplete_test003() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[98], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void
    rdftests_rdfcore_rdfmssyntaxincomplete_test004() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[99], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void
    rdftests_rdfcore_rdfmsurisubstructure_test001() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[100], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void
    rdftests_rdfcore_rdfmsxmlliteralnamespaces_test001() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[101], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void
    rdftests_rdfcore_rdfmsxmlliteralnamespaces_test002() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[102], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_rdfmsxmllang_test001() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[103], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_rdfmsxmllang_test002() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[104], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_rdfmsxmllang_test003() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[105], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_rdfmsxmllang_test004() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[106], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_rdfmsxmllang_test005() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[107], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_rdfmsxmllang_test006() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[108], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void
    rdftests_rdfcore_rdfsdomainandrange_test001() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[109], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void
    rdftests_rdfcore_rdfsdomainandrange_test002() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[110], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void
    rdftests_rdfcore_unrecognisedxmlattributes_test001() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[111], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void
    rdftests_rdfcore_unrecognisedxmlattributes_test002() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[112], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_xmlcanon_test001() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[113], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_xmlbase_test001() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[114], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_xmlbase_test002() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[115], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_xmlbase_test003() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[116], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_xmlbase_test004() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[117], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_xmlbase_test006() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[118], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_xmlbase_test007() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[119], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_xmlbase_test008() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[120], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_xmlbase_test009() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[121], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_xmlbase_test010() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[122], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_xmlbase_test011() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[123], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_xmlbase_test013() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[124], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }

  /// <summary>
  /// Test
  /// </summary>
  [NUnit.Framework.Test]
  public void rdftests_rdfcore_xmlbase_test014() 
  {
    Data.executeTest(Data.PositiveParserTests_etc1[125], "etc1-results-net.n3", "PositiveParserTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
  }
}

}
