// $Id: PositiveEntailmentTest_ETC2.cs 1295 2007-05-11 16:52:51Z josd $

namespace Eulersharp.test 
{

  using System;
  using System.IO;
  using System.Reflection;

  /// <summary>
  /// Class to test the euler engine
  /// </summary>
  [NUnit.Framework.TestFixture]
  public class PositiveEntailmentTest_ETC2
  {

    /// <summary>
    /// Code to set up the test
    /// </summary>
    [NUnit.Framework.SetUp]
    public void Init() 
    {
      Outputter.getInstance().initialize("etc2-results-net.n3");
    }

    /// <summary>
    /// Code to shut down the test
    /// </summary>
    [NUnit.Framework.TearDown]
    public void TearDown()
    {
      File.Delete("test.n3");
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void AllDifferent_001() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[0], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void AnnotationProperty_002() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[1], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void Class_002() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[2], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void Class_003() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[3], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void Class_006() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[4], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void FunctionalProperty_001() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[5], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void FunctionalProperty_002() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[6], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void FunctionalProperty_003() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[7], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void FunctionalProperty_004() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[8], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void FunctionalProperty_005() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[9], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I4_5_001() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[10], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I4_6_003() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[11], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I5_1_001() 
  {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[12], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I5_2_002() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[13], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I5_2_004() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[14], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I5_2_006() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[15], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I5_21_002() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[16], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I5_24_001() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[17], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I5_24_002() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[18], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I5_24_003() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[19], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I5_24_004() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[20], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I5_26_009() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[21], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I5_26_010() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[22], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I5_3_014() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[23], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I5_3_015() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[24], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I5_5_005() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[25], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I5_8_004() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[26], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I5_8_006() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[27], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I5_8_008() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[28], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I5_8_009() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[29], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I5_8_010() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[30], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I5_8_017() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[31], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void InverseFunctionalProperty_001() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[32], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void InverseFunctionalProperty_002() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[33], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void InverseFunctionalProperty_003() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[34], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void InverseFunctionalProperty_004() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[35], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void Ontology_001() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[36], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void Ontology_004() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[37], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void Restriction_006() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[38], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void SymmetricProperty_001() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[39], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void SymmetricProperty_002() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[40], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void SymmetricProperty_003() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[41], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void TransitiveProperty_001() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[42], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void TransitiveProperty_002() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[43], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void allValuesFrom_001() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[44], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void cardinality_001() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[45], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void cardinality_002() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[46], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void cardinality_003() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[47], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void cardinality_004() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[48], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void cardinality_006() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[49], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void complementOf_001() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[50], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void description_logic_201() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[51], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void description_logic_202() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[52], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void description_logic_203() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[53], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void description_logic_204() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[54], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void description_logic_205() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[55], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void description_logic_206() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[56], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void description_logic_207() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[57], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void description_logic_208() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[58], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void description_logic_661() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[59], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void description_logic_662() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[60], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void description_logic_663() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[61], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void description_logic_664() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[62], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void description_logic_665() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[63], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void description_logic_667() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[64], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void description_logic_901() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[65], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void description_logic_903() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[66], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void differentFrom_001() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[67], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void differentFrom_002() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[68], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void disjointWith_001() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[69], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void disjointWith_002() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[70], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void distinctMembers_001() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[71], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void equivalentClass_001() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[72], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void equivalentClass_002() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[73], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void equivalentClass_003() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[74], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void equivalentClass_004() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[75], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void equivalentClass_006() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[76], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void equivalentClass_007() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[77], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void equivalentProperty_001() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[78], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void equivalentProperty_002() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[79], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void equivalentProperty_003() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[80], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void equivalentProperty_004() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[81], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void equivalentProperty_005() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[82], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void equivalentProperty_006() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[83], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void extra_credit_002() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[84], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void extra_credit_003() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[85], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void extra_credit_004() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[86], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void intersectionOf_001() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[87], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void inverseOf_001() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[88], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void miscellaneous_010() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[89], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void miscellaneous_011() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[90], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void oneOf_002() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[91], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void oneOf_003() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[92], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void oneOf_004() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[93], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void sameAs_001() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[94], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void someValuesFrom_001() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[95], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void someValuesFrom_003() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[96], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void unionOf_001() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[97], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void unionOf_002() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[98], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void unionOf_003() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[99], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void unionOf_004() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc2[100], "etc2-results-net.n3", "PositiveEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

  }
}
