// $Id: ETC3.cs 1295 2007-05-11 16:52:51Z josd $

namespace Eulersharp.test 
{

  using System;
  using System.IO;
  using System.Reflection;

  /// <summary>
  /// Class to test the euler engine
  /// </summary>
  [NUnit.Framework.TestFixture]
  public class ETC3
  {

    /// <summary>
    /// Code to set up the test
    /// </summary>
    [NUnit.Framework.SetUp]
    public void Init() 
    {
      Outputter.getInstance().initialize("etc3-results-net.n3");
    }

    /// <summary>
    /// Code to shut down the test
    /// </summary>
    [NUnit.Framework.TearDown]
    public void TearDown()
    {
      File.Delete("test.n3");
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void euler_authen_axiom() 
    {
      Data.executeTest(Data.etc3[0], "etc3-results-net.n3", "ETC3_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void euler_graph_axiom() 
    {
      Data.executeTest(Data.etc3[1], "etc3-results-net.n3", "ETC3_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void euler_gedcom_relations() 
    {
      Data.executeTest(Data.etc3[2], "etc3-results-net.n3", "ETC3_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void euler_danc() 
    {
      Data.executeTest(Data.etc3[3], "etc3-results-net.n3", "ETC3_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void euler_ziv() 
    {
      Data.executeTest(Data.etc3[4], "etc3-results-net.n3", "ETC3_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void euler_danb() 
    {
      Data.executeTest(Data.etc3[5], "etc3-results-net.n3", "ETC3_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void euler_test() 
    {
      Data.executeTest(Data.etc3[6], "etc3-results-net.n3", "ETC3_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void euler_animal() 
    {
      Data.executeTest(Data.etc3[7], "etc3-results-net.n3", "ETC3_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void euler_subprop() 
    {
      Data.executeTest(Data.etc3[8], "etc3-results-net.n3", "ETC3_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void euler_subclass() 
    {
      Data.executeTest(Data.etc3[9], "etc3-results-net.n3", "ETC3_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void euler_rdfsfacts() 
    {
      Data.executeTest(Data.etc3[10], "etc3-results-net.n3", "ETC3_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void euler_owlfacts() 
    {
      Data.executeTest(Data.etc3[11], "etc3-results-net.n3", "ETC3_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void euler_builtins() 
    {
      Data.executeTest(Data.etc3[12], "etc3-results-net.n3", "ETC3_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void rdftests_rdfcore_entailment_etc001() 
    {
      Data.executeTest(Data.etc3[13], "etc3-results-net.n3", "ETC3_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void RGML_N3_rgml_rules() 
    {
      Data.executeTest(Data.etc3[14], "etc3-results-net.n3", "ETC3_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void test_08swws67_poolGamekb() 
    {
      Data.executeTest(Data.etc3[15], "etc3-results-net.n3", "ETC3_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void test_2000_10_swap_test_pathCross() 
    {
      Data.executeTest(Data.etc3[16], "etc3-results-net.n3", "ETC3_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void euler_dtP() 
    {
      Data.executeTest(Data.etc3[17], "etc3-results-net.n3", "ETC3_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void test_2002_10_medicad_op_lldmD() 
    {
      Data.executeTest(Data.etc3[18], "etc3-results-net.n3", "ETC3_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void eulersharp_pimP() 
    {
      Data.executeTest(Data.etc3[19], "etc3-results-net.n3", "ETC3_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void euler_logfacts() 
    {
      Data.executeTest(Data.etc3[20], "etc3-results-net.n3", "ETC3_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void euler_easterP() 
    {
      Data.executeTest(Data.etc3[21], "etc3-results-net.n3", "ETC3_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void eulersharp_continentsP() 
    {
      Data.executeTest(Data.etc3[22], "etc3-results-net.n3", "ETC3_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void rdftests_rdfcore_ntriples_test() 
    {
      Data.executeTest(Data.etc3[23], "etc3-results-net.n3", "ETC3_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void test_03owlt_mapInvP() 
    {
      Data.executeTest(Data.etc3[24], "etc3-results-net.n3", "ETC3_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void test_03owlt_mapVocabP() 
    {
      Data.executeTest(Data.etc3[25], "etc3-results-net.n3", "ETC3_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void test_03owlt_oneOfP() 
    {
      Data.executeTest(Data.etc3[26], "etc3-results-net.n3", "ETC3_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void test_03owlt_pathTransitiveP() 
    {
      Data.executeTest(Data.etc3[27], "etc3-results-net.n3", "ETC3_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void test_03owlt_unionOfP() 
    {
      Data.executeTest(Data.etc3[28], "etc3-results-net.n3", "ETC3_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void test_03owlt_sameGuyP() 
    {
      Data.executeTest(Data.etc3[29], "etc3-results-net.n3", "ETC3_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void test_03owlt_sameStateP() 
    {
      Data.executeTest(Data.etc3[30], "etc3-results-net.n3", "ETC3_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void test_03owlt_dbP() 
    {
      Data.executeTest(Data.etc3[31], "etc3-results-net.n3", "ETC3_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void test_03owlt_intersectionOfP() 
    {
      Data.executeTest(Data.etc3[32], "etc3-results-net.n3", "ETC3_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void test_03owlt_SocratesP() 
    {
      Data.executeTest(Data.etc3[33], "etc3-results-net.n3", "ETC3_" + MethodBase.GetCurrentMethod().Name);
    }

  }
}
