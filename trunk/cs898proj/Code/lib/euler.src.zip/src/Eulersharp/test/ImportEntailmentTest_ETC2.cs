// $Id: ImportEntailmentTest_ETC2.cs 1295 2007-05-11 16:52:51Z josd $

namespace Eulersharp.test 
{

  using System;
  using System.IO;
  using System.Reflection;

  /// <summary>
  /// Class to test the euler engine
  /// </summary>
  [NUnit.Framework.TestFixture]
  public class ImportEntailmentTest_ETC2
  {

    /// <summary>
    /// Code to set up the test
    /// </summary>
    [NUnit.Framework.SetUp]
    public void Init() 
    {
      Outputter.getInstance().initialize("etc2-results-net.n3");
    }

    /// <summary>
    /// Code to shut down the test
    /// </summary>
    [NUnit.Framework.TearDown]
    public void TearDown()
    {
      File.Delete("test.n3");
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void test001() 
    {
      Data.executeTest(Data.ImportEntailmentTest_etc2[0], "etc2-results-net.n3", "ImportEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void test003() 
    {
      Data.executeTest(Data.ImportEntailmentTest_etc2[1], "etc2-results-net.n3", "ImportEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void test011() 
    {
      Data.executeTest(Data.ImportEntailmentTest_etc2[2], "etc2-results-net.n3", "ImportEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

  }
}
