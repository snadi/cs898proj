// $Id: StdOutputter.cs 1295 2007-05-11 16:52:51Z josd $

namespace Eulersharp.Output 
{
  using System;

  /**
   * This class redirects all output from euler to standard output
   */

  public class StdOutputter:ILogger, IProof, IResult 
  {

    #region Declarations

    private static object       LOCK     = new object();
    private static StdOutputter instance = null;

    private Outputter.LOGLEVEL _logLevel = Outputter.LOGLEVEL.SEVERE;      // log everything by default

    #endregion

    #region Constructor and Destructor

    /// <summary>
    /// This method constructs an instance of the StdOutLogger class. This
    /// constructor is private because this class is a singleton. The only
    /// instance of this class should be retrieved via the getInstance() method.
    /// </summary>
    private StdOutputter() 
    {
      Outputter.GetInstance().AddLogger(this);
      Outputter.GetInstance().AddProofListener(this);
      Outputter.GetInstance().AddResultListener(this);
    }

    /// <summary>
    /// This class acts as a singleton. getInstance() returns the only instance of
    /// this class.
    /// </summary>
    /// <returns>the only instance of this class</returns>
    public static StdOutputter GetInstance() 
    {
      lock (LOCK) 
      {
        if (instance == null) 
        {
          instance = new StdOutputter();
        }
      }
      return instance;
    }

    /// <summary>
    /// This method releases the only instance of this class. All internal
    /// state will be cleared.
    /// </summary>
    public static void ReleaseInstance() 
    {
      lock (LOCK) 
      {
        if (instance != null) 
        {
          // clear all internal state
          Outputter.GetInstance().RemoveLogger(instance);
          Outputter.GetInstance().RemoveProofListener(instance);
          Outputter.GetInstance().RemoveResultListener(instance);
          // clear instance
          instance = null;
        }
      }
    }

    #endregion

    #region Implementation of interface ILogger

    /// <summary>
    /// This method prints a log message on std out
    /// </summary>
    /// <param name="className">the name of the class that initiated the message</param>
    /// <param name="methodName">the method that initiated the log message</param>
    /// <param name="message">the log message</param>
    /// <param name="logLevel">the log level</param>
    public void Log(string className, string methodName, string message, Outputter.LOGLEVEL logLevel) 
    {
      if (logLevel <= _logLevel) {
        Console.WriteLine("LOG:    (" + logLevel.ToString() + ") " + className + "::" + methodName + " => " + message);
      }
    }

    #endregion

    #region Implementation of interface IResult

    /// <summary>
    /// This method prints a result on std out.
    /// </summary>
    /// <param name="testCase">the name of the test case</param>
    /// <param name="result">the result of the test case</param>
    public void Result(string testCase, string result) 
    {
      Console.WriteLine("RESULT: (" + testCase + ") " + result);
    }

    #endregion

    #region Implementation of interface IProof

    /// <summary>
    /// This method prints a proof on std out.
    /// </summary>
    /// <param name="testCase">the name of the test case</param>
    /// <param name="proof">the proof (if found)</param>
    public void Proof(string testCase, string proof) 
    {
      Console.WriteLine("PROOF:  (" + testCase + ") " + proof);
    }

    #endregion

    #region Public methods

    /// <summary>
    /// This method sets the log level. All log methods with a log level higher 
    /// than this loglevel will be logged on the standard output stream.
    /// </summary>
    /// <param name="logLevel">the threshold log level</param>
    public void setLogLevel(Outputter.LOGLEVEL logLevel) 
    {
      if (Enum.IsDefined(typeof(Outputter.LOGLEVEL), logLevel))
      {
        _logLevel = logLevel;
      }
    }

    #endregion 

    /*public static void Main(string[] args) 
    {
      StdOutputter.GetInstance();
      Outputter.GetInstance().Log("StdOutputter", "main", "Starting test", Outputter.LOGLEVEL.SEVERE);
      Outputter.GetInstance().Result("test 1", "success");
      Outputter.GetInstance().Proof("test 1", "proof");
      Outputter.GetInstance().Log("StdOutputter", "main", "Stopping test", Outputter.LOGLEVEL.SEVERE);
      Console.ReadLine();
    }*/

  }
}
