namespace Eulersharp.Output 
{

  using System;
  using System.Collections;
  using System.Runtime.CompilerServices;

  /// <summary>
  /// This class manages the output from the euler component
  /// </summary>
  public class Outputter:ILogger, IProof, IResult 
  {

    #region Declarations

    private static object    LOCK     = new object();
    private static Outputter instance = null;

    /// <summary>
    /// Flag that indicates whether there are log listeners interested in logging
    /// info.
    /// </summary>
    public static bool log = false;

    /// <summary>
    /// This enumeration defines the different log levels
    /// </summary>
    public enum LOGLEVEL {
      /// <summary>
      /// SEVERE log level
      /// </summary>
      SEVERE, 
      /// <summary>
      /// SEVERE log level
      /// </summary>
      WARNING, 
      /// <summary>
      /// WARNING log level
      /// </summary>
      INFO, 
      /// <summary>
      /// INFO log level
      /// </summary>
      CONFIG, 
      /// <summary>
      /// CONFIG log level
      /// </summary>
      FINE, 
      /// <summary>
      /// FINE log level
      /// </summary>
      FINER, 
      /// <summary>
      /// FINEST log level
      /// </summary>
      FINEST
    };

    private ArrayList _logListeners    = null;
    private ArrayList _proofListeners  = new ArrayList ();
    private ArrayList _resultListeners = new ArrayList ();

    #endregion

    #region Constructor and Destructor

    /// <summary>
    /// This method constructs an instance of the outputter class. This
    /// constructor is private because this class is a singleton. The only
    /// instance of this class should be retrieved via the getInstance() method.
    /// </summary>
    private Outputter() 
    {
    }

    /// <summary>
    /// This class acts as a singleton. getInstance() returns the only instance of
    /// this class.
    /// </summary>
    /// <returns>the only instance of this class</returns>
    public static Outputter GetInstance() 
    {
      lock(LOCK) 
      {
        if (instance == null) 
        {
          instance = new Outputter();
        }
      }
      return instance;
    }

    /// <summary>
    /// This method releases the only instance of this class. All internal
    /// state will be cleared. 
    /// </summary>
    public static void ReleaseInstance() 
    {
      lock(LOCK) 
      {
        if (instance != null) 
        {
          // clear all internal state
          instance._logListeners    = null;
          instance._proofListeners  = null;
          instance._resultListeners = null;
          // clear instance
          instance = null;
        }
      }
    }

    #endregion

    #region Public methods

    /// <summary>
    /// This method registers a log listener. From now on this log listener will
    /// also receive log messages from the euler component
    /// </summary>
    /// <param name="logger">the logger to be registered.</param>
    [MethodImpl(MethodImplOptions.Synchronized)]
    public void AddLogger(ILogger logger) 
    { 
      if (_logListeners == null) 
      {
        _logListeners = new ArrayList();
        log = true;
      }
      if (!_logListeners.Contains(logger)) 
      {
        _logListeners.Add(logger);
      }
    }

    /// <summary>
    /// This method unregisters a log listener. From now on this log listener will
    /// receive no log messages anymore from the euler component.
    /// </summary>
    /// <param name="logger">the logger to be removed as a listener.</param>
    [MethodImpl(MethodImplOptions.Synchronized)]
    public void RemoveLogger(ILogger logger) 
    {
      if (_logListeners.Contains(logger)) 
      {
        _logListeners.Remove(logger);
      }
      if (_logListeners.Count == 0) 
      {
        _logListeners = null;
        log = false;
      }
    }

    /// <summary>
    /// This method registers a result listener. From now on this result listener
    /// will also receive the results of the different test cases 
    /// </summary>
    /// <param name="result">the result listener to be registered.</param>
    [MethodImpl(MethodImplOptions.Synchronized)]
    public void AddResultListener(IResult result) 
    {
      if (!_resultListeners.Contains(result)) 
      {
        _resultListeners.Add(result);
      }
    }

    /// <summary>
    /// This method unregisters a result listener. From now on this result 
    /// listener will receive no results anymore from the euler component.
    /// </summary>
    /// <param name="result">the result listener to be removed.</param>
    [MethodImpl(MethodImplOptions.Synchronized)]
    public void RemoveResultListener(IResult result) 
    {
      if (_resultListeners.Contains(result)) 
      {
        _resultListeners.Remove(result);
      }
    }

    /// <summary>
    /// This method registers a proof listener. From now on this proof listener
    /// will also receive the proofs of the different test cases
    /// </summary>
    /// <param name="proof">the proof listener to be registered.</param>
    [MethodImpl(MethodImplOptions.Synchronized)]
    public void AddProofListener(IProof proof) 
    {
      if (!_proofListeners.Contains(proof)) 
      {
        _proofListeners.Add(proof);
      }
    }

    /// <summary>
    /// This method unregisters a proof listener. From now on this proof listener
    /// will receive no proofs anymore from the euler component.  
    /// </summary>
    /// <param name="proof">the proof listener to be removed.</param>
    [MethodImpl(MethodImplOptions.Synchronized)]
    public void RemoveProofListener(IProof proof) 
    {
      if (_proofListeners.Contains(proof)) 
      {
        _proofListeners.Remove(proof);
      }
    }

    #endregion

    #region Implementation of interface ILogger

    /// <summary>
    /// This method distributes a log message to the different interested log
    /// </summary>
    /// <param name="className">the name of the class that initiated the message</param>
    /// <param name="methodName">the method that initiated the log message</param>
    /// <param name="message">the log message</param>
    /// <param name="logLevel">the log level</param>
    [MethodImpl(MethodImplOptions.Synchronized)]
    public void Log(string className, string methodName, string message, LOGLEVEL logLevel) 
    {
      if (_logListeners != null && Enum.IsDefined(typeof(LOGLEVEL), logLevel))
      {
        for (IEnumerator en = _logListeners.GetEnumerator(); en.MoveNext();) 
        {
          ( (ILogger) en.Current).Log(className, methodName, message, logLevel);
        }
      }
    }

    #endregion

    #region Implementation of interface IResult

    /// <summary>
    /// This method distributes the result of a test case to the different
    /// interested listeners.  
    /// </summary>
    /// <param name="testCase">the name of the test case</param>
    /// <param name="result">the result of the test case</param>
    [MethodImpl(MethodImplOptions.Synchronized)]
    public void Result(string testCase, string result) 
    {
      for (IEnumerator en = _resultListeners.GetEnumerator(); en.MoveNext();) 
      {
        ((IResult) en.Current).Result(testCase, result);
      }
    }

    #endregion

    #region Implementation of interface IProof

    /// <summary>
    /// This method reports the proof for a specific test case
    /// </summary>
    /// <param name="testCase">the name of the test case</param>
    /// <param name="proof">the proof (if found)</param>
    [MethodImpl(MethodImplOptions.Synchronized)]
    public void Proof(string testCase, string proof) 
    {
      for (IEnumerator en = _proofListeners.GetEnumerator(); en.MoveNext();) 
      {
        ((IProof) en.Current).Proof(testCase, proof);
      }
    }

    #endregion

  }
}

