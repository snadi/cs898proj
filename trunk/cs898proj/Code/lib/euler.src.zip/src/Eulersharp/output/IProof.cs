namespace Eulersharp.Output
{

  /// <summary>
  /// This interface specifies the methods for reporting a proof 
  /// for a specific test case
  /// </summary>
  public interface IProof 
  {

    /// <summary>
    /// This method reports the proof for a specific test case
    /// </summary>
    /// <param name="testCase">the name of the test case</param>
    /// <param name="proof">the proof (if found)</param>
    void Proof(string testCase, string proof);

  }

}